﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace login
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=loginsys;Integrated Security=True;");
            conn.Open();
            string hash = BCrypt.Net.BCrypt.HashPassword(txtpassword.Text);
            string sql = "insert into [dbo].[Table] (username,password) values ('" + txtusername.Text + "','" + hash + "')";
            SqlCommand command = new SqlCommand(sql, conn);
            command.ExecuteNonQuery();
            command.Dispose();
            conn.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=loginsys;Integrated Security=True;");
            conn.Open();
            SqlDataReader datareader;
            string sql = "select password from [dbo].[Table] where username='" + txtusername.Text + "'";
            SqlCommand command = new SqlCommand(sql, conn);
            datareader = command.ExecuteReader();
            while(datareader.Read())
            {
                bool verify = BCrypt.Net.BCrypt.Verify(txtpassword.Text, datareader.GetString(0));
                if(verify)
                {
                    MessageBox.Show("right");
                }
                else
                {
                    MessageBox.Show("wrong");
                }

            }
        }
    }
}
